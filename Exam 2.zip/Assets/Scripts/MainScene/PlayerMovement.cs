using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField]
    private float speed = 0.15f;

    [SerializeField]
    private float minX = -20f;

    [SerializeField]
    private float maxX = 20f;

    [SerializeField]
    private float minZ = 0f;

    [SerializeField]
    private float maxZ = 20f;

    private Transform transformCached;
    private float horizontalAxis;
    private float positionZ;

    // Start is called before the first frame update
    void Start()
    {
        transformCached = transform;
        positionZ = transformCached.position.z;
    }

    // Update is called once per frame
    void Update()
    {
        if (!Player.IsAlive)
        {
            return;
        }

        horizontalAxis = Input.GetAxis("Horizontal");

        transform.Translate(Vector3.right * speed * horizontalAxis * Time.deltaTime);

        if(transform.position.z > maxZ) {
            transform.position = new Vector3(transform.position.x, transform.position.y, maxZ);
        }

        if (transform.position.z < minZ) {
            transform.position = new Vector3(transform.position.x, transform.position.y, minZ);
        }

        if (transform.position.x > maxX) {
            transform.position = new Vector3(maxX,transform.position.y, transform.position.z);
        }
        if(transform.position.x < minX) {
            transform.position = new Vector3(minX, transform.position.y, transform.position.z);
        }
        // Rotation
        float targetAngle = horizontalAxis * 20;
        float progress = Mathf.Abs(horizontalAxis);
        float yAngle = Mathf.LerpAngle(transformCached.rotation.eulerAngles.y, targetAngle, progress);
        transformCached.rotation = Quaternion.Euler(0f, yAngle, 0f);
    }
}
