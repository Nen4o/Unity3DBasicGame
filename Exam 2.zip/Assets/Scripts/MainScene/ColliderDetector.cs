using UnityEngine;

public class ColliderDetector : MonoBehaviour
{
    public IntEvent OnObstacleHit;

    public Effects effects;
    
    void OnCollisionEnter(Collision collision)
    {

        if (Player.IsAlive && collision.gameObject.tag == "Health") {
            OnObstacleHit.Invoke(collision.gameObject.GetComponent<Obstacle>().Damage);
            effects.GatherFuel(collision.gameObject.GetComponent<Obstacle>().Damage);
        }

        if (Player.IsAlive && collision.gameObject.tag == "Obstacle")
        {
            OnObstacleHit.Invoke(collision.gameObject.GetComponent<Obstacle>().Damage);
            effects.ObstacleHit(collision.gameObject.GetComponent<Obstacle>().Damage);
        }
    }
}
