using Unity.VisualScripting;
using UnityEngine;

public class Effects : MonoBehaviour
{
    [SerializeField]
    private ParticleSystem crashEffect;

    [SerializeField]
    private AudioSource carAudioSource;

    [SerializeField]
    private AudioSource AudioEffectSource;

    [SerializeField]
    private float nitroEnginePitch;

    [SerializeField]
    private AudioClip fuelGatherClip;

    [SerializeField]
    private AudioClip crashClip;

    [SerializeField]
    private AudioClip SqueakySound;

    private float normalEnginePitch;

    public Player player;

    private bool isLooped;
    public void Awake()
    {
        normalEnginePitch = carAudioSource.pitch;
        isLooped = false;
    }

    private void Update() {
        if(!isLooped) {
            if (!Player.IsAlive) {

                //crashEffect.transform.SetLocalPositionAndRotation(player.transform.position, Quaternion.identity);
                crashEffect.Play();
                AudioEffectSource.PlayOneShot(crashClip);
                isLooped = true;
            }
        }

    }
    public void GatherFuel(int value)
    {
        if (value > 0)
        {
            AudioEffectSource.PlayOneShot(fuelGatherClip);
        }
    }

    public void ObstacleHit(int value)
    {
        if (Player.IsAlive && value < 0)
        {
            AudioEffectSource.PlayOneShot(SqueakySound);
        }
    }

    
}
