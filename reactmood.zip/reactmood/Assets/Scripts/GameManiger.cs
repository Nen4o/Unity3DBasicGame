using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManiger : MonoBehaviour
{

    public GameObject circlePrefab;

    public int lives;
    public int score;

    //private int hightScore;

    private float maxPosX;
    private float maxPosY;

    private int hightScore;
    public GameObject[] circleLeft;

    public TextMeshProUGUI livesText;
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI hightscoreText;

    public GameObject deadPanel;
    public GameObject pausePanel;



    // Start is called before the first frame update
    void Start()
    {

        hightScore = PlayerPrefs.GetInt("hightScore");
        Time.timeScale = 1f;

        Debug.Log("S" + hightScore);

        maxPosX = 1.5f;
        maxPosY = 3f;
        lives = 3; // to change on 3!!!

//        PlayerPrefs.SetInt("hightScore", hightScore);
    }

    // Update is called once per frame
    void Update()
    {
        circleLeft = GameObject.FindGameObjectsWithTag("Player");

        if(circleLeft.Length == 0) {
            SpawnCircle();
        }

        if(lives == 0) {


            if (PlayerPrefs.GetInt("hightScore") < score) {

                hightScore = score;
                PlayerPrefs.SetInt("hightScore", hightScore);
                PlayerPrefs.Save();
             }

            deadPanel.SetActive(true);
            hightscoreText.SetText("hightscore: " + hightScore);
            Debug.Log("You Lose");
        }
    }

    void SpawnCircle() {

        if(lives > 0) {

            float randomPosX = Random.Range(-maxPosX, maxPosX);
            float randomPosY = Random.Range(-maxPosY, maxPosY);

            Instantiate(circlePrefab, new Vector3(randomPosX, randomPosY, 0f), circlePrefab.transform.rotation);

            Debug.Log(lives);
        }
    }

    public void GoToMainMenu() {

        SceneManager.LoadScene("MenuScene");
    }

    public void PlayAgain() {
        
        PlayerPrefs.SetInt("hightScore", hightScore);
        Debug.Log("B" + hightScore);
        PlayerPrefs.Save();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Debug.Log("A" + hightScore);
    }

    public void QuitGame() {
        Application.Quit();
        Debug.Log("Quit");
    }

    public void OnPauseClick() {
        Time.timeScale = 0f;
        pausePanel.SetActive(true);
    }

    public void OnResumeClick() {
        Time.timeScale = 1f;
        pausePanel.SetActive(false);
    }

}
