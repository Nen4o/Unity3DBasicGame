using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuScripts : MonoBehaviour
{

    public GameObject playerObj;
    private CircleScript circleScript;

    private void Start() {
        circleScript = playerObj.GetComponent<CircleScript>();
    }
    public void StartEasyGame() {
        circleScript.time = 2;
        circleScript.playMode = "Easy";
        SceneManager.LoadScene("GameScene");
        Debug.Log("time: " + circleScript.time);
    }

    public void StartMediumMode() {
        circleScript.time = 1;
        circleScript.playMode = "Medium";
        SceneManager.LoadScene("GameScene");
        Debug.Log("time: " + circleScript.time);
    }

    public void StartHardMode() {
        circleScript.time = 0.5f;
        circleScript.playMode = "Hard";
        SceneManager.LoadScene("GameScene");
        Debug.Log("time: " + circleScript.time);
    }

    public void QuitGame() {
        Application.Quit();
        Debug.Log("Quit");
    }
}
